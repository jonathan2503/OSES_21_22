#ifndef NAVIGATE
#define NAVIGATE
    int navigate(int [4], int *); // arguments: obstacle array, pointer to chosen direction
    int initNavigation(int, int, int, int); // arguments: starting_row, starting_column, destination_row, destination_column
#endif
