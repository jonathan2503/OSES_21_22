#include <rtthread.h>
#include <rtdevice.h>
#include <rtdbg.h>
#include  "pin_select.h"


void all_pin_low();
void communication(int direction);

